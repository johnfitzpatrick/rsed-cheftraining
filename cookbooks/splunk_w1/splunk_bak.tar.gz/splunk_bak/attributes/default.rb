default[:splunk][:install]     = "/opt"
default[:splunk][:user]        = "splunk"
default[:splunk][:installer]   = "https://rs-training-assets.s3.amazonaws.com/splunk-4.3.4-136012-Linux-x86_64.tar"
